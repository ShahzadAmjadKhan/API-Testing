
##################################
class APIClient(object):
    session = None
    response = None
    header = None

    def __init__(self, user):
        self.user = user

##################################
