from keycloak import Client
from requests import Session
import logging

logger = logging.getLogger(__name__)

###############################################################################
# Class APISession extends Session
class APISession(Session):
    """
    This class extends requests.Session and is supposed to behave exactly
    the same, with additions specific to the CB Portal APIs:

     After calling the login() method, the result of the login (success or not)
    can be checked with the following attribute:
    - world.client.session.login_successful
    This attribute will return True in case of a successful login, False
    otherwise
    """

    ###########################################################################
    request_stats = {}

    ###########################################################################
    def __init__(self):

        # Call parent constructor
        Session.__init__(self)

        # Set (and declare) some instance attributes
        self.environment = 'undefined'
        self.token_type = 'access-token'
        self.login_method = 'open-id-connect'
        self.login_successful = False
        self.token = None
        # Make sure we do not do ssl verification for every request
        self.verify = False

    ###########################################################################
    def login(self, username, password):
        """Do the login for the API session."""
        logger = logging.getLogger('APISession.login()')
        print(username)
        print(password)
        # It reads the keycloak.json file available at root directory and tries to get the token
        kc = Client(username=username, password=password)
        self.token = kc.access_token
        print(self.token)
        self.login_successful = True

    ###########################################################################
    def setEnvironment(self, env):
        self.environment = env

    ###########################################################################
    def getToken(self):
        return self.token

