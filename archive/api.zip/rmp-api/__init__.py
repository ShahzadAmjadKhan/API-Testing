import os


with open("keycloak.json", 'r') as ff:
    data = ff.read()
data = os.path.expandvars(data)
ff.close()
with open("keycloak.json", 'w') as ff:
     ff.write(data)
ff.close()