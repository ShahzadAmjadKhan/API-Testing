import os
from datetime import datetime
from aloe import *
import logging
import requests

ENVIRONMENT = os.environ['RMP_APP_URL']
logger = logging.getLogger('rmp-test-logger')


@before.all
def setup_logging():
    LOGIN_METHOD = ''
    DEBUG_LEVEL = logging.getLevelName(os.environ.get('DEBUG_LEVEL','DEBUG'))
    logging.basicConfig(level=DEBUG_LEVEL, format='[%(asctime)s %(levelname)s %(name)s %(funcName)s()]: %(message)s ')
    logging.info("Using settings: ENVIRONMENT: {}, LOGIN_METHOD: {}, DEBUG_LEVEL: {}".format(ENVIRONMENT,LOGIN_METHOD,DEBUG_LEVEL))

@before.all
def supress_urllib3_warnings():
    requests.packages.urllib3.disable_warnings()

@before.all
def say_hello():
    global test_start_time
    test_start_time = datetime.now()
    logger.info("Aloe starting for RMP API test at: {} ...".format(test_start_time))

@before.each_example
def init_user_id(*scenario):
    world.user_id = None