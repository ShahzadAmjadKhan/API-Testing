import sys
import os

# Adding parent root directory into the path variable to access common module
root_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
sys.path.insert(0, root_dir)