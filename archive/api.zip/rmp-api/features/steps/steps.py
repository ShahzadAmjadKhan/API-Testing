import json
import logging
import os
from datetime import date

from aloe import *
from modules.apiclient import APIClient
from modules.apisession import APISession

ENVIRONMENT = os.environ['RMP_APP_URL']
logger = logging.getLogger(__name__)

@step(u'I am not logged in')
def init_session(step):
     world.client = APIClient('NPA')
     world.client.session = APISession()
     world.environment = ENVIRONMENT
     world.client.session.setEnvironment(ENVIRONMENT)
     world.field_value = None
     world.base_url = '/rmp/api'
     print("Print me")

@step(u'I am logged in as (.*)$')
def logged_in_as_user(step, username):
    print("Print inside I am logged in as")
    print(os.getcwd())
    world.client = APIClient(username)
    # For this client, create an APISession
    world.client.session = APISession()
    world.client.session.setEnvironment(ENVIRONMENT)

    world.client.session.login(username, get_password(username))
    world.environment = ENVIRONMENT
    world.field_value = None
    world.base_url = '/rmp/api'
    print("Exiting I am logged in as")


@step(u'The response for (\w+) "([^"]*)" is "([^"]*)"')
def check_response(step, method, api, request_id):
    respjson = json.loads(world.client.session.response.content)

    expresp = json.loads(get_message(request_id, method, api, False))
    se1 = list(set(get_special_elements_in_dict(expresp, "#STRING")))
    se2 = list(set(get_special_elements_in_dict(expresp, 44448888)))

    respjson = replace_special_characters_in_dict(respjson, se1, "#STRING")
    respjson = replace_special_characters_in_dict(respjson, se2, 44448888)

    assert respjson == expresp, "Got response: {}, expected: {}".format(respjson, expresp)


@step(u'I call (\w+) "([^"]*)" with query parameters "([^"]*)"')
def send_request_for_api2(step, method, api, parms):
    print("with parameters")
    print(step)
    send_request(method, api, None, parms)


@step(u'I call (\w+) "([^"]*)" with request "([^"]*)"')
def send_request_for_api3(step, method, api, request_id):
    send_request(method, api, request_id, None)


@step(u'I call (\w+) "([^"]*)" with conversationid "([^"]*)"')
def send_request_for_api4(step, method, api, conversationid):
    send_request(method, api, None, None, conversationid)

@step(u'I call (\w+) "([^"]*)"')
def send_request_for_api1(step, method, api):
    print("without parameters")
    send_request(method, api, None, None)


def send_request(method, api, request_id, parms, convid=None):
    #api = api.replace('#INPUT', str(world.field_value))

    if convid is not None:
        conversation_id = convid
    else:
        if request_id is not None:
            conversation_id = request_id
        else:
            conversation_id = 'none'

    if request_id is not None:
        folder = api

        for p in api.split('/'):
            if p.isdigit() or str(p).find('{', 0, len(str(p))) >= 0:
                folder = folder.replace('/' + p, '')

        req = get_message(request_id, method, folder, True)
    else:
        req = ''

    req = replace_placeholders(req)

    api = api.replace('{', '').replace('}', '')

    if parms is not None:
        parms = replace_placeholders(parms)
        pp = '?' + parms
    else:
        pp = ''

    token = ''
    if world.client.session.getToken() is not None:
        token = 'Bearer ' + str(world.client.session.getToken())

    #world.environment is https://host:port
    #world.base_url is /rmp/api
    #api is v1/leave-types
    url = '{}{}/{}{}'.format(world.environment, world.base_url, api, pp)
    headers = {'Content-type': 'application/json;charset=utf-8', 'conversationId': conversation_id,
               'sendingPartyId': 'rmp-api-test',
               'oauth-full-name-attribute': 'name',
               'oauth-email-attribute': 'email',
               'oauth-group-attribute': 'groups',
               'oauth-public-key-uri': 'https://vm-rmp-tomcat-l01.redmath.org:9447/rmp-auth/api/v1/oauth/public-key',
               'oauth-admin-group-names': 'System Admins',
               'oauth-user-name-attribute': 'preferred_username',
               'oauth-company-id': '2',
               'Authorization': token
               }

    if world.user_id is not None:
        headers['user-id'] = world.user_id

    print('url = ' + method.upper() + ' ' + url)
    print('req = ' + req)
    print('headers = ')
    print(headers)

    if method.upper() == 'POST':
        world.client.session.response = world.client.session.post(url, data=req, headers=headers)
    elif method.upper() == 'PUT':
        world.client.session.response = world.client.session.put(url, data=req, headers=headers)
    elif method.upper() == 'PATCH':
        world.client.session.response = world.client.session.patch(url, data=req, headers=headers)
    elif method.upper() == 'DELETE':
        world.client.session.response = world.client.session.delete(url, headers=headers)
    elif method.upper() == 'GET':
        world.client.session.response = world.client.session.get(url, headers=headers)

    print('status= ' + str(world.client.session.response.status_code))
    print('response = ' + str(world.client.session.response.content))


def get_message(req_id, method, apiname, request=True):
    apiname = apiname.replace('/', '_')
    #data_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), 'data', apiname, method)
    data_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__)))), 'data', apiname, method)

    if request:
        ext = '.request'
    else:
        ext = '.response'

    with open(os.path.join(data_dir, req_id + ext), 'r') as ff:
        c = ff.read()
        print("calling placeholder to replace")
        c = replace_placeholders(c)

    return c

def replace_placeholders(req):
    today = date.today()
    return req.replace('#CURRENT_DATE', today.strftime("%Y-%m-%d"))

def get_special_elements_in_list(d, elmt_value):
    se = []

    for k in d:
        if isinstance(k, dict):
            se.extend(get_special_elements_in_dict(k, elmt_value))
        elif isinstance(k, list):
            se.extend(get_special_elements_in_list(k, elmt_value))

    return se


def get_special_elements_in_dict(d, elmt_value):
    se = []

    for key in d:
        if isinstance(d[key], dict):
            se.extend(get_special_elements_in_dict(d[key], elmt_value))
        elif isinstance(d[key], list):
            se.extend(get_special_elements_in_list(d[key], elmt_value))
        else:
            if d[key] == elmt_value:
                se.append(key)

    return se


def replace_special_characters_in_list(d, sclist, elmt_value):
    d_out = []

    for k in d:
        if isinstance(k, dict):
            d_out.append(replace_special_characters_in_dict(k, sclist, elmt_value))
        elif isinstance(k, list):
            d_out.append(replace_special_characters_in_list(k, sclist, elmt_value))
        else:
            d_out.append(k)

    return d_out


def replace_special_characters_in_dict(d, sclist, elmt_value):
    d_out = {}

    for key in d:
        if isinstance(d[key], dict):
            d_out[key] = replace_special_characters_in_dict(d[key], sclist, elmt_value)
        elif isinstance(d[key], list):
            d_out[key] = replace_special_characters_in_list(d[key], sclist, elmt_value)
        else:
            if key in sclist:
                d_out[key] = elmt_value
            else:
                d_out[key] = d[key]

    return d_out


@step(u'I get the value of field "([^"]*)"')
def get_field_value(step, field):
    respjson = json.loads(world.client.session.response.content)

    world.field_value = respjson[field]


# inject input value in request
def inject_field_value(jsn):
    for key in jsn:
        if jsn[key] == '#INPUT':
            jsn[key] = world.field_value

    return jsn


@step(u'I call "([^"]*)" with file "([^"]*)"')
def call_with_file(step, api, filename):
    send_multipartform_request(api, filename, filename, 'application/vnd.ms-excel')


@step(u'I call "([^"]*)" with file "([^"]*)" and filename "([^"]*)"')
def call_with_file(step, api, filename1, filename2):
    send_multipartform_request(api, filename1, filename2, 'application/vnd.ms-excel')


def send_multipartform_request(api, filename_for_read, filename_in_msg, contenttype):
    folder = api.replace('/', '_')

    url = 'http://{}/{}/{}'.format(world.environment, world.base_url, api)
    data_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), 'data', folder, 'POST')

    params = {
        'importfile': (filename_in_msg, open(os.path.join(data_dir, filename_for_read), 'rb'), contenttype)
    }

    world.client.session.response = world.client.session.post(url, files=params)

    print('response = ' + world.client.session.response.content)


@step(u'The raw response for (\w+) "([^"]*)" is "([^"]*)"')
def check_response1(step, method, api, request_id):
    expresp = get_message(request_id, method, api, False)

    assert world.client.session.response.content == expresp, "Got response: {}, expected: {}".format(world.client.session.response.content, expresp)


@step(u'I set the header userid to "([^"]*)"')
def set_user_id(step, uid):
    world.user_id = uid


@step(u'I set the base url to "([^"]*)"')
def set_base_url(step, base_url):
    world.base_url = base_url

@step(u'The http status code is (\d+)')
def http_status_code(step, status_code):
    assert world.client.session.response.status_code == int(status_code), "status code should be {} but was {}".format(status_code, world.client.session.response.status_code)

def get_password(login_name):
    password = login_name[0:login_name.find("@")]
    password = password[0].upper() + password[1:len(password)]
    return password